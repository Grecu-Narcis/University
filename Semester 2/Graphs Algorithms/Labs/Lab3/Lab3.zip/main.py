from domain.directed_graph import *
from ui.ui import UI


# graph = read_graph_from_file_1('graph.txt')
# print(graph.min_cost_walks(1, 3))
#
ui = UI()

ui.main_menu()
