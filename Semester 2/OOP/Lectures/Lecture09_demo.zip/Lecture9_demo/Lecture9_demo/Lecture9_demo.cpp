#include "Lecture9_demo.h"

Lecture9_demo::Lecture9_demo(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

Lecture9_demo::~Lecture9_demo()
{}
