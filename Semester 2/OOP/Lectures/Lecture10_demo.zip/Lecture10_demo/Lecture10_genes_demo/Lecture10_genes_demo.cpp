#include "Lecture10_genes_demo.h"

Lecture10_genes_demo::Lecture10_genes_demo(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

Lecture10_genes_demo::~Lecture10_genes_demo()
{}
